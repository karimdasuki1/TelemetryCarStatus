Hello... this is README file

Atte:
Jorge Daniel Aguilar Orozco.
Karim Dasuki Garcia.
Juan De la Hoz FOnseca.
Jorge Lambraño Arroyo.
